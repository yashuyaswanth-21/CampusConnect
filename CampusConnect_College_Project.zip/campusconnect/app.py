from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path
from datetime import datetime

app = Flask(__name__)
app.secret_key = "change-this-for-production"
DB_PATH = Path(__file__).with_name("campusconnect.db")

def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS posts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                location TEXT DEFAULT '',
                contact TEXT DEFAULT '',
                created_at TEXT NOT NULL
            )
        """)
        count = conn.execute("SELECT COUNT(*) FROM posts").fetchone()[0]
        if count == 0:
            now = datetime.now().strftime("%d %b %Y")
            samples = [
                ("Notice", "Internal assessment schedule released", "Check with your department for the latest internal assessment timetable.", "Academic Block", "College Office", now),
                ("Event", "Campus Innovation Day", "Showcase your projects, prototypes, and creative ideas. All departments are welcome.", "Main Auditorium", "Student Council", now),
                ("Lost & Found", "Found: Blue water bottle", "A blue water bottle was found near the library entrance.", "Central Library", "Campus Help Desk", now),
            ]
            conn.executemany("""
                INSERT INTO posts (category, title, description, location, contact, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, samples)

@app.route("/")
def index():
    search = request.args.get("q", "").strip()
    category = request.args.get("category", "All")
    with connect_db() as conn:
        if search and category != "All":
            rows = conn.execute("""
                SELECT * FROM posts
                WHERE category = ? AND (title LIKE ? OR description LIKE ? OR location LIKE ?)
                ORDER BY id DESC
            """, (category, f"%{search}%", f"%{search}%", f"%{search}%")).fetchall()
        elif search:
            rows = conn.execute("""
                SELECT * FROM posts
                WHERE title LIKE ? OR description LIKE ? OR location LIKE ?
                ORDER BY id DESC
            """, (f"%{search}%", f"%{search}%", f"%{search}%")).fetchall()
        elif category != "All":
            rows = conn.execute("SELECT * FROM posts WHERE category = ? ORDER BY id DESC", (category,)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM posts ORDER BY id DESC").fetchall()
        counts = {
            "all": conn.execute("SELECT COUNT(*) FROM posts").fetchone()[0],
            "notice": conn.execute("SELECT COUNT(*) FROM posts WHERE category='Notice'").fetchone()[0],
            "event": conn.execute("SELECT COUNT(*) FROM posts WHERE category='Event'").fetchone()[0],
            "lost": conn.execute("SELECT COUNT(*) FROM posts WHERE category='Lost & Found'").fetchone()[0],
        }
    return render_template("index.html", posts=rows, search=search, category=category, counts=counts)

@app.route("/add", methods=["POST"])
def add_post():
    category = request.form.get("category", "").strip()
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    location = request.form.get("location", "").strip()
    contact = request.form.get("contact", "").strip()

    allowed = {"Notice", "Event", "Lost & Found"}
    if category not in allowed or not title or not description:
        flash("Please complete the required fields and choose a valid category.", "error")
        return redirect(url_for("index"))

    created_at = datetime.now().strftime("%d %b %Y")
    with connect_db() as conn:
        conn.execute("""
            INSERT INTO posts (category, title, description, location, contact, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (category, title, description, location, contact, created_at))
    flash("Your post was added successfully!", "success")
    return redirect(url_for("index"))

@app.route("/delete/<int:post_id>", methods=["POST"])
def delete_post(post_id):
    with connect_db() as conn:
        conn.execute("DELETE FROM posts WHERE id = ?", (post_id,))
    flash("Post deleted.", "success")
    return redirect(url_for("index"))

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
